# Usage

## Built with
- React Router 6, ShadCN UI, Tailwind, Lucide Icons, ESLint, Vite
- Platform-agnostic backend support (can be deployed to Cloudflare Workers, Google App Engine, or any hosting platform)

## Restrictions
- Tailwind: define custom colors in `tailwind.config.js` (not in `index.css`)
- Do not modify template-owned config files like `vite.config.ts` or `tsconfig*.json`
- If a change is required, request it instead of editing those files

## Styling
- Responsive, accessible
- Prefer ShadCN components; Tailwind utilities for custom parts
- Icons from `lucide-react`
- Error boundaries are already implemented

## Animation
- Use `framer-motion` for small interactions when needed

## Components
- Import from `@/components/ui/*` (ShadCN). Avoid reinventing components.

## Example
```tsx
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

export function Example() {
  return (
    <Card className="max-w-sm">
      <CardContent className="p-4 flex gap-2">
        <Button>Click</Button>
      </CardContent>
    </Card>
  )
}
```

## Backend (optional)
- If you add backend routes, do it in `worker/index.ts` (or your platform's entry point). Follow the existing pattern carefully to avoid breakage.
- The backend can be deployed to Cloudflare Workers, Google App Engine, or any Node.js-compatible hosting platform.